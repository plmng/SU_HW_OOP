﻿namespace _04.SoftUniLearningSystem.SULTClasses
{
    public class Student: Person
    {
        public string StudentNumber { get; set; }
        public double AverageGrade { get; set; }
    }
}
