﻿namespace _04.SoftUniLearningSystem.SULTClasses
{
    public class JuniorTrainer : Trainer
    {
       
    }
}
