﻿using System;
class Persons
{
    static void Main()
    {
        Person prsn = new Person("Pesho", 10);
        Console.WriteLine(prsn);
    }
}
