﻿namespace TheBank.Customers
{
    public class Company:Customer
    {
        public Company(string name) : base(name)
        {
        }
    }
}
