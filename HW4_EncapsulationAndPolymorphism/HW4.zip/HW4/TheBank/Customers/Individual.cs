﻿namespace TheBank.Customers
{
    public class Individual : Customer
    {
        public Individual(string name) : base(name)
        {
        }
    }
}
