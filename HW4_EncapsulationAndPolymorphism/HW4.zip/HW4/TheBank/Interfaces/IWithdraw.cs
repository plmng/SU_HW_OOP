﻿namespace TheBank.Interfaces
{
    public interface IWithdraw
    {
        string Withdraw(decimal amounth);
    }
}
