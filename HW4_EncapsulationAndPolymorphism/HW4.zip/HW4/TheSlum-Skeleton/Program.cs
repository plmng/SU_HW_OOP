﻿namespace TheSlum
{
    using GameEngine;

    public class Program
    {
        public static void Main()
        {
            var engine = new CustomEngine();
            engine.Run();
        }
    }
}